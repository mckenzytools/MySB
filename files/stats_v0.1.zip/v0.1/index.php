<?php
// ----------------------------------
//  __/\\\\____________/\\\\___________________/\\\\\\\\\\\____/\\\\\\\\\\\\\___
//   _\/\\\\\\________/\\\\\\_________________/\\\/////////\\\_\/\\\/////////\\\_
//    _\/\\\//\\\____/\\\//\\\____/\\\__/\\\__\//\\\______\///__\/\\\_______\/\\\_
//     _\/\\\\///\\\/\\\/_\/\\\___\//\\\/\\\____\////\\\_________\/\\\\\\\\\\\\\\__
//      _\/\\\__\///\\\/___\/\\\____\//\\\\\________\////\\\______\/\\\/////////\\\_
//       _\/\\\____\///_____\/\\\_____\//\\\____________\////\\\___\/\\\_______\/\\\_
//        _\/\\\_____________\/\\\__/\\_/\\\______/\\\______\//\\\__\/\\\_______\/\\\_
//         _\/\\\_____________\/\\\_\//\\\\/______\///\\\\\\\\\\\/___\/\\\\\\\\\\\\\/__
//          _\///______________\///___\////__________\///////////_____\/////////////_____
//			By toulousain79 ---> https://github.com/toulousain79/
//
//#####################################################################
//
//	Copyright (c) 2013 toulousain79 (https://github.com/toulousain79/)
//	Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:
//	The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
//	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
//	IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
//	--> Licensed under the MIT license: http://www.opensource.org/licenses/mit-license.php
//
//#################### FIRST LINE #####################################

// Infos stats
define('STATS_VERSION', '0.1');
define('WEB_ROOT', dirname(__FILE__));

// First include
require_once WEB_ROOT.'/inc/const.php';
require_once WEB_ROOT.'/inc/vars.php';
require_once WEB_ROOT.'/inc/db.php';

if ( $HttpUserAgent == USER_AGENT ) {
	$version = $_POST["version"];
	$machine_id = $_POST["machine_id"];
	$country = geoip_country_name_by_name($RequestIp);

	if ( ($version != '') && ($machine_id != '') ) {
		$Stats_DB->insert("stats", ["version" => "$version", "machine_id" => "$machine_id", "date" => "$Date $Hour", "country" => "$country"]);
		$result = $Stats_DB->id();

		if( $result != 0 ) {
			echo "Statistics updated at $Date $Hour, machine_id: $machine_id !";
		}
	}
} else {
	$CountInstall = $Stats_DB->count("stats", "stats_id");


	$AllStats = $Stats_DB->select("stats", ["version", "date", "country"], ["ORDER" => "date ASC"]);
?>

	<div align="center">
		<table style="border-spacing:1;">
			<tr>
				<th>Total install</th>
			</tr>
			<tr style="text-align:center;">
				<td><?php echo $CountInstall; ?></td>
			</tr>
		</table>
	</div>

	<div align="center">
		<table style="border-spacing:1;">
			<tr>
				<th>Versions</th>
				<th>Country</th>
				<th>Date</th>
			</tr>

<?php
	foreach($AllStats as $Stats) {
?>
			<tr style="text-align:center;">
				<td ><?php echo $Stats["version"]; ?></td>
				<td><?php echo $Stats["country"]; ?></td>
				<td><?php echo $Stats["date"]; ?></td>
			</tr>
<?php
	}
?>
		</table>
	</div>
<?php
}

//#################### LAST LINE ######################################
